# 🚀 Panduan Deployment LES KOMPUTER ke Hosting Gratis

## Informasi Login Admin
- **Username**: `admin`
- **Password**: `admin123`
- ⚠️ **PENTING**: Segera ganti password default setelah deploy!

---

## Opsi 1: Vercel (Rekomendasi - Gratis & Termudah)

Vercel adalah platform hosting gratis terbaik untuk Next.js. Tidak perlu kartu kredit.

### Langkah-langkah:

#### 1. Buat Akun GitHub
- Buka https://github.com dan buat akun (jika belum punya)

#### 2. Upload Project ke GitHub
- Install Git di komputer: https://git-scm.com/downloads
- Buka terminal/command prompt di folder project
- Jalankan perintah:
```bash
git init
git add .
git commit -m "Initial commit - LES KOMPUTER website"
git branch -M main
```
- Buat repository baru di GitHub (klik "New Repository")
- Jalankan:
```bash
git remote add origin https://github.com/USERNAME/les-komputer.git
git push -u origin main
```
(Ganti USERNAME dengan username GitHub Anda)

#### 3. Deploy ke Vercel
- Buka https://vercel.com dan sign up dengan akun GitHub
- Klik **"Add New..."** → **"Project"**
- Pilih repository `les-komputer` dari daftar
- Di bagian **Environment Variables**, tambahkan:
  - Key: `DATABASE_URL` | Value: `file:./dev.db`
- Klik **"Deploy"**
- Tunggu hingga proses selesai (±2-3 menit)
- Website Anda akan live di URL seperti: `les-komputer.vercel.app`

#### 4. Seed Database (Isi Data Awal)
- Setelah deploy, buka browser dan akses:
  `https://NAMA-PROJECT.vercel.app/api/seed`
- Ini akan mengisi data awal (kursus, testimoni, admin)

#### 5. Buka Website
- Kunjungi URL yang diberikan Vercel
- Klik tombol Admin di navbar untuk masuk ke panel admin

### ⚠️ Catatan Vercel
- Vercel menggunakan serverless functions → database SQLite bersifat sementara
- Data akan reset jika tidak ada aktivitas dalam beberapa menit
- **Cocok untuk**: Demo, portofolio, website promosi yang datanya jarang berubah
- **Jika butuh data persisten**: Gunakan Opsi 2 (Railway)

---

## Opsi 2: Railway (Gratis + Data Persisten)

Railway mendukung penyimpanan file permanen, cocok untuk SQLite.

### Langkah-langkah:

#### 1. Upload ke GitHub (sama seperti Opsi 1, langkah 1-2)

#### 2. Deploy ke Railway
- Buka https://railway.app dan sign up dengan GitHub
- Klik **"New Project"** → **"Deploy from GitHub repo"**
- Pilih repository `les-komputer`
- Di tab **Variables**, tambahkan:
  - `DATABASE_URL` = `file:./data/leskomputer.db`
- Di tab **Settings**:
  - Build Command: `npm run build`
  - Start Command: `npm run start`
- Railway akan otomatis build dan deploy

#### 3. Seed Database
- Akses: `https://NAMA-PROJECT.up.railway.app/api/seed`

---

## Opsi 3: VPS Gratis (Oracle Cloud / Google Cloud)

Jika ingin kontrol penuh, gunakan VPS gratis.

### Langkah-langkah:

#### 1. Buat VPS Gratis
- Oracle Cloud Free Tier: https://cloud.oracle.com (selamanya gratis, 1GB RAM)
- Atau Google Cloud: https://cloud.google.com (free trial $300)

#### 2. Install di VPS
```bash
# SSH ke VPS
ssh ubuntu@IP-VPS-ANDA

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install Bun (alternatif lebih cepat)
curl -fsSL https://bun.sh/install | bash

# Clone project dari GitHub
git clone https://github.com/USERNAME/les-komputer.git
cd les-komputer

# Install dependencies
npm install

# Setup database
npx prisma db push
npx tsx scripts/seed.ts

# Build
npm run build

# Jalankan dengan PM2 (agar tetap berjalan)
npm install -g pm2
pm2 start npm --name "les-komputer" -- start
pm2 save
pm2 startup

# Website berjalan di http://IP-VPS:3000
```

#### 3. Setup Domain (Opsional)
- Daftar domain gratis di https://www.freenom.com atau beli domain murah
- Point domain ke IP VPS Anda

---

## Opsi 4: Netlify (Alternatif)

### Langkah-langkah:

#### 1. Upload ke GitHub (sama seperti langkah di atas)

#### 2. Deploy ke Netlify
- Buka https://netlify.com dan sign up dengan GitHub
- Klik **"Add new site"** → **"Import an existing project"**
- Pilih repository `les-komputer`
- Build command: `npm run build`
- Publish directory: `.next`
- Tambahkan environment variable `DATABASE_URL` = `file:./dev.db`
- Klik **"Deploy site"**

---

## 📁 Struktur File Project

```
les-komputer/
├── prisma/
│   └── schema.prisma        # Skema database
├── public/
│   ├── hero-image.png       # Foto halaman depan
│   ├── about-image.png      # Foto tentang kami
│   └── uploads/             # Folder upload foto admin
├── scripts/
│   └── seed.ts              # Script isi data awal
├── src/
│   ├── app/
│   │   ├── api/             # Backend API routes
│   │   │   ├── auth/        # Login, logout, check
│   │   │   ├── config/      # Pengaturan website
│   │   │   ├── courses/     # Kelola kursus
│   │   │   ├── enrollments/ # Pendaftaran
│   │   │   ├── seed/        # Isi data awal
│   │   │   ├── testimonials/# Testimoni
│   │   │   └── upload/      # Upload foto
│   │   ├── layout.tsx       # Layout utama
│   │   ├── page.tsx         # Halaman utama (landing + admin)
│   │   └── globals.css      # Styling global
│   ├── components/ui/       # Komponen UI shadcn
│   ├── hooks/               # React hooks
│   └── lib/
│       ├── db.ts            # Koneksi database
│       └── utils.ts         # Fungsi utilitas
├── .env.example             # Contoh environment variables
├── next.config.ts           # Konfigurasi Next.js
├── package.json             # Dependencies
├── tailwind.config.ts       # Konfigurasi Tailwind CSS
└── vercel.json              # Konfigurasi Vercel
```

---

## 🔧 Environment Variables

| Variable | Value | Keterangan |
|----------|-------|------------|
| `DATABASE_URL` | `file:./dev.db` | Path database SQLite |

---

## ❓ FAQ

### Q: Data hilang setelah deploy di Vercel?
A: Vercel menggunakan serverless functions, sehingga database SQLite bersifat sementara. Solusi:
1. Gunakan Railway (Opsi 2) untuk data persisten
2. Atau upgrade ke database PostgreSQL (Vercel Postgres gratis 256MB)

### Q: Bagaimana ganti password admin?
A: Login admin → Pengaturan → Saat ini belum ada fitur ganti password, tapi bisa langsung di database.

### Q: Bisa pakai domain sendiri?
A: Ya! Di Vercel/Railway, bisa menambahkan custom domain di settings.

### Q: Foto upload hilang?
A: Di Vercel, file upload juga bersifat sementara. Gunakan Railway atau VPS untuk penyimpanan permanen.

### Q: Berapa batas hosting gratis?
A:
- **Vercel**: 100GB bandwidth/bulan, unlimited deploy
- **Railway**: $5 credit/bulan (cukup untuk project kecil)
- **Oracle Cloud VPS**: Selamanya gratis (1GB RAM, 1 CPU)

---

## 📞 Bantuan

Jika mengalami masalah:
1. Pastikan Node.js versi 18+ terinstall
2. Pastikan semua file terupload ke GitHub
3. Cek log error di dashboard Vercel/Railway
4. Jalankan `npm run build` secara lokal untuk cek error
