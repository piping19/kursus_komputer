// Seed script - jalankan dengan: bun run seed atau npx tsx scripts/seed.ts
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const db = new PrismaClient()

async function main() {
  console.log('🌱 Menyemai data awal...')

  // 1. Create default admin if not exists
  const existingAdmin = await db.admin.findFirst({ where: { username: 'admin' } })
  if (!existingAdmin) {
    const hashedPassword = await bcrypt.hash('admin123', 10)
    await db.admin.create({
      data: {
        username: 'admin',
        password: hashedPassword,
        name: 'Administrator',
      },
    })
    console.log('✅ Admin dibuat (username: admin, password: admin123)')
  } else {
    console.log('⏭️  Admin sudah ada, dilewati')
  }

  // 2. Create sample courses if none exist
  const existingCourses = await db.course.count()
  if (existingCourses === 0) {
    await db.course.createMany({
      data: [
        {
          title: 'Kursus Komputer Dasar',
          description: 'Pelajari dasar-dasar komputer untuk pemula',
          level: 'Pemula',
          price: 500000,
          duration: '8 Pertemuan',
          icon: 'Monitor',
          features: 'Ms. Word|Ms. Excel|Internet|Email',
          order: 1,
        },
        {
          title: 'Kursus Desain Grafis',
          description: 'Kuasai desain grafis dengan tool profesional',
          level: 'Menengah',
          price: 750000,
          duration: '10 Pertemuan',
          icon: 'Palette',
          features: 'Adobe Photoshop|CorelDRAW|Canva|Figma',
          order: 2,
        },
        {
          title: 'Kursus Programming',
          description: 'Belajar programming dari dasar hingga mahir',
          level: 'Menengah',
          price: 1000000,
          duration: '12 Pertemuan',
          icon: 'Code',
          features: 'HTML & CSS|JavaScript|Python|Database',
          order: 3,
        },
        {
          title: 'Kursus Web Development',
          description: 'Bangun website modern dengan teknologi terkini',
          level: 'Lanjutan',
          price: 1500000,
          duration: '16 Pertemuan',
          icon: 'Globe',
          features: 'React|Next.js|Node.js|MongoDB',
          order: 4,
        },
        {
          title: 'Kursus Microsoft Office',
          description: 'Kuasai Microsoft Office untuk meningkatkan produktivitas',
          level: 'Pemula',
          price: 400000,
          duration: '6 Pertemuan',
          icon: 'FileSpreadsheet',
          features: 'Word|Excel|PowerPoint|Outlook',
          order: 5,
        },
        {
          title: 'Kursus Editing Video',
          description: 'Pelajari editing video profesional',
          level: 'Menengah',
          price: 900000,
          duration: '10 Pertemuan',
          icon: 'Video',
          features: 'Premiere Pro|DaVinci Resolve|After Effects|CapCut',
          order: 6,
        },
      ],
    })
    console.log('✅ 6 kursus ditambahkan')
  } else {
    console.log('⏭️  Kursus sudah ada, dilewati')
  }

  // 3. Create sample testimonials if none exist
  const existingTestimonials = await db.testimonial.count()
  if (existingTestimonials === 0) {
    await db.testimonial.createMany({
      data: [
        {
          name: 'Siti Nurhaliza',
          role: 'Mahasiswa',
          content: 'Les programming di sini sangat terstruktur dan mudah dipahami. Sekarang saya sudah bisa membuat website sendiri untuk tugas kuliah!',
          rating: 5,
          order: 1,
        },
        {
          name: 'Rizky Pratama',
          role: 'Siswa SMK',
          content: 'Saya belajar desain grafis dari nol, sekarang sudah bisa bikin poster dan edit foto untuk kegiatan sekolah. Seru banget!',
          rating: 5,
          order: 2,
        },
        {
          name: 'Dewi Lestari',
          role: 'Umum - Freelancer',
          content: 'Les desain grafis membuka peluang karir baru buat saya. Sekarang saya bisa menerima project desain dan penghasilan tambahan!',
          rating: 5,
          order: 3,
        },
        {
          name: 'Fajar Nugroho',
          role: 'Siswa SMA',
          content: 'Les MS Office sangat membantu untuk mengerjakan tugas sekolah. Pengajarnya sabar dan materinya lengkap.',
          rating: 5,
          order: 4,
        },
      ],
    })
    console.log('✅ 4 testimoni ditambahkan')
  } else {
    console.log('⏭️  Testimoni sudah ada, dilewati')
  }

  // 4. Create site config entries if none exist
  const existingConfig = await db.siteConfig.count()
  if (existingConfig === 0) {
    await db.siteConfig.createMany({
      data: [
        { key: 'site_name', value: 'LES KOMPUTER' },
        { key: 'site_tagline', value: 'Mahasiswa, SMA/SMK Sederajat, Umum' },
        { key: 'site_phone', value: '0812-3456-7890' },
        { key: 'site_email', value: 'info@leskomputer.id' },
        { key: 'site_address', value: 'Jl. Teknologi No. 123, Jakarta Selatan' },
        { key: 'site_whatsapp', value: '6281234567890' },
        { key: 'site_hero_image', value: '/hero-image.png' },
        { key: 'site_about_image', value: '/about-image.png' },
      ],
    })
    console.log('✅ Konfigurasi website ditambahkan')
  } else {
    console.log('⏭️  Konfigurasi sudah ada, dilewati')
  }

  console.log('🎉 Selesai! Data awal berhasil disiapkan.')
}

main()
  .catch((e) => {
    console.error('❌ Error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
