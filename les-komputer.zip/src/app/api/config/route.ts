import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

function checkAuth(request: NextRequest) {
  const token = request.cookies.get('admin_token')?.value
  if (!token) return null
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString())
    if (payload.exp < Date.now()) return null
    return payload
  } catch { return null }
}

export async function GET() {
  const configs = await db.siteConfig.findMany()
  const configMap: Record<string, string> = {}
  for (const c of configs) {
    configMap[c.key] = c.value
  }
  return NextResponse.json({ config: configMap })
}

export async function PUT(request: NextRequest) {
  const admin = checkAuth(request)
  if (!admin) {
    return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
  }

  const body = await request.json()
  const { key, value } = body

  if (!key) {
    return NextResponse.json({ success: false, message: 'Key is required' }, { status: 400 })
  }

  const config = await db.siteConfig.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  })

  return NextResponse.json({ success: true, config })
}
