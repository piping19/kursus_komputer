import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

function checkAuth(request: NextRequest) {
  const token = request.cookies.get('admin_token')?.value
  if (!token) return null
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString())
    if (payload.exp < Date.now()) return null
    return payload
  } catch {
    return null
  }
}

export async function GET(request: NextRequest) {
  const auth = checkAuth(request)
  if (!auth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const enrollments = await db.enrollment.findMany({
    include: { course: true },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({ enrollments })
}

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { name, email, phone, courseId, message } = body

  if (!name || !email || !phone || !courseId) {
    return NextResponse.json(
      { error: 'name, email, phone, and courseId are required' },
      { status: 400 }
    )
  }

  const course = await db.course.findUnique({ where: { id: courseId } })
  if (!course) {
    return NextResponse.json(
      { error: 'Course not found' },
      { status: 404 }
    )
  }

  const enrollment = await db.enrollment.create({
    data: {
      name,
      email,
      phone,
      courseId,
      message: message ?? null,
      status: 'pending',
    },
    include: { course: true },
  })

  return NextResponse.json({ success: true, enrollment })
}
