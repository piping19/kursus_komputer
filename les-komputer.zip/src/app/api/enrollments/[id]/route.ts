import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

function checkAuth(request: NextRequest) {
  const token = request.cookies.get('admin_token')?.value
  if (!token) return null
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString())
    if (payload.exp < Date.now()) return null
    return payload
  } catch {
    return null
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = checkAuth(request)
  if (!auth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id } = await params
  const body = await request.json()

  if (!body.status) {
    return NextResponse.json(
      { error: 'status is required' },
      { status: 400 }
    )
  }

  const existing = await db.enrollment.findUnique({ where: { id } })
  if (!existing) {
    return NextResponse.json(
      { error: 'Enrollment not found' },
      { status: 404 }
    )
  }

  const enrollment = await db.enrollment.update({
    where: { id },
    data: { status: body.status },
    include: { course: true },
  })

  return NextResponse.json({ success: true, enrollment })
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = checkAuth(request)
  if (!auth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id } = await params

  const existing = await db.enrollment.findUnique({ where: { id } })
  if (!existing) {
    return NextResponse.json(
      { error: 'Enrollment not found' },
      { status: 404 }
    )
  }

  await db.enrollment.delete({ where: { id } })

  return NextResponse.json({ success: true })
}
