import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

function verifyAdmin(request: NextRequest): boolean {
  const token = request.cookies.get('admin_token')?.value
  if (!token) return false

  try {
    const decoded = JSON.parse(atob(token))
    if (decoded.expires && Date.now() > decoded.expires) return false
    return true
  } catch {
    return false
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const isAdmin = searchParams.get('admin') === 'true'

    const courses = await db.course.findMany({
      where: isAdmin ? {} : { isActive: true },
      orderBy: { order: 'asc' },
    })

    return NextResponse.json({ courses })
  } catch (error) {
    console.error('Failed to fetch courses:', error)
    return NextResponse.json({ error: 'Failed to fetch courses' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  if (!verifyAdmin(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { title, description, icon, duration, price, level, features, image, isActive, order } = body

    if (!title || !description) {
      return NextResponse.json({ error: 'Title and description are required' }, { status: 400 })
    }

    const course = await db.course.create({
      data: {
        title,
        description,
        icon: icon ?? 'Monitor',
        duration: duration ?? '8 Pertemuan',
        price: price ?? 0,
        level: level ?? 'Pemula',
        features: features ?? '',
        image: image ?? null,
        isActive: isActive ?? true,
        order: order ?? 0,
      },
    })

    return NextResponse.json({ success: true, course })
  } catch (error) {
    console.error('Failed to create course:', error)
    return NextResponse.json({ error: 'Failed to create course' }, { status: 500 })
  }
}
