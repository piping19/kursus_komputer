import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

function checkAuth(request: NextRequest) {
  const token = request.cookies.get('admin_token')?.value
  if (!token) return null
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString())
    if (payload.exp < Date.now()) return null
    return payload
  } catch {
    return null
  }
}

export async function GET() {
  const testimonials = await db.testimonial.findMany({
    where: { isActive: true },
    orderBy: { order: 'asc' },
  })
  return NextResponse.json({ testimonials })
}

export async function POST(request: NextRequest) {
  const auth = checkAuth(request)
  if (!auth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await request.json()
  const { name, role, content, rating, avatar, isActive, order } = body

  if (!name || !role || !content) {
    return NextResponse.json(
      { error: 'name, role, and content are required' },
      { status: 400 }
    )
  }

  const testimonial = await db.testimonial.create({
    data: {
      name,
      role,
      content,
      rating: rating ?? 5,
      avatar: avatar ?? null,
      isActive: isActive ?? true,
      order: order ?? 0,
    },
  })

  return NextResponse.json({ success: true, testimonial })
}
