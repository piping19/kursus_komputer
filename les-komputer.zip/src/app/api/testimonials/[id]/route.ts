import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

function checkAuth(request: NextRequest) {
  const token = request.cookies.get('admin_token')?.value
  if (!token) return null
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString())
    if (payload.exp < Date.now()) return null
    return payload
  } catch {
    return null
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = checkAuth(request)
  if (!auth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id } = await params
  const body = await request.json()

  const existing = await db.testimonial.findUnique({ where: { id } })
  if (!existing) {
    return NextResponse.json(
      { error: 'Testimonial not found' },
      { status: 404 }
    )
  }

  const testimonial = await db.testimonial.update({
    where: { id },
    data: {
      ...(body.name !== undefined && { name: body.name }),
      ...(body.role !== undefined && { role: body.role }),
      ...(body.content !== undefined && { content: body.content }),
      ...(body.rating !== undefined && { rating: body.rating }),
      ...(body.avatar !== undefined && { avatar: body.avatar }),
      ...(body.isActive !== undefined && { isActive: body.isActive }),
      ...(body.order !== undefined && { order: body.order }),
    },
  })

  return NextResponse.json({ success: true, testimonial })
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = checkAuth(request)
  if (!auth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id } = await params

  const existing = await db.testimonial.findUnique({ where: { id } })
  if (!existing) {
    return NextResponse.json(
      { error: 'Testimonial not found' },
      { status: 404 }
    )
  }

  await db.testimonial.delete({ where: { id } })

  return NextResponse.json({ success: true })
}
