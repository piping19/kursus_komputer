import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('admin_token')?.value

    if (!token) {
      return NextResponse.json({ authenticated: false })
    }

    // Decode the base64 token
    const decoded = JSON.parse(
      Buffer.from(token, 'base64').toString('utf-8')
    )

    // Check if token has expired
    if (!decoded.exp || decoded.exp <= Date.now()) {
      const response = NextResponse.json({ authenticated: false })
      response.cookies.set('admin_token', '', {
        httpOnly: true,
        path: '/',
        maxAge: 0,
        sameSite: 'lax',
      })
      return response
    }

    // Validate that required fields exist
    if (!decoded.id || !decoded.username || !decoded.name) {
      return NextResponse.json({ authenticated: false })
    }

    return NextResponse.json({
      authenticated: true,
      admin: {
        id: decoded.id,
        username: decoded.username,
        name: decoded.name,
      },
    })
  } catch {
    return NextResponse.json({ authenticated: false })
  }
}
