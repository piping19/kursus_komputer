import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "LES KOMPUTER - Mahasiswa, SMA/SMK Sederajat, Umum",
  description: "Les komputer untuk Mahasiswa, SMA/SMK Sederajat, dan Umum. Belajar dari dasar hingga mahir: Ms. Office, Desain Grafis, Programming, Web Development, dan Editing Video.",
  keywords: ["les komputer", "kursus komputer", "belajar komputer", "les komputer mahasiswa", "les komputer SMA", "kursus programming", "kursus desain grafis"],
  authors: [{ name: "LES KOMPUTER" }],
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
