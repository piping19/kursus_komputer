"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Monitor, Palette, Code, Globe, FileSpreadsheet, Video,
  Star, Phone, Mail, MapPin, ChevronRight, Menu, X,
  LogOut, LayoutDashboard, BookOpen, MessageSquare, Users,
  Settings, Plus, Pencil, Trash2, Eye, CheckCircle, Clock,
  XCircle, Loader2, GraduationCap, Award, Zap, Heart,
  ArrowRight, MessageCircle, ImageIcon, Upload
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";

// Types
interface Course {
  id: string;
  title: string;
  description: string;
  icon: string;
  duration: string;
  price: number;
  level: string;
  features: string;
  image?: string;
  isActive: boolean;
  order: number;
}

interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  avatar?: string;
  isActive: boolean;
  order: number;
}

interface Enrollment {
  id: string;
  name: string;
  email: string;
  phone: string;
  courseId: string;
  course?: Course;
  message?: string;
  status: string;
  createdAt: string;
}

interface Admin {
  id: string;
  username: string;
  name: string;
}

interface SiteConfig {
  site_name: string;
  site_tagline: string;
  site_phone: string;
  site_email: string;
  site_address: string;
  site_whatsapp: string;
  [key: string]: string;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Monitor, Palette, Code, Globe, FileSpreadsheet, Video,
};

const levelColors: Record<string, string> = {
  Pemula: "bg-emerald-100 text-emerald-700",
  Menengah: "bg-amber-100 text-amber-700",
  Lanjutan: "bg-rose-100 text-rose-700",
};

const statusColors: Record<string, string> = {
  pending: "bg-amber-100 text-amber-700",
  confirmed: "bg-emerald-100 text-emerald-700",
  completed: "bg-teal-100 text-teal-700",
  cancelled: "bg-rose-100 text-rose-700",
};

const statusLabels: Record<string, string> = {
  pending: "Menunggu",
  confirmed: "Dikonfirmasi",
  completed: "Selesai",
  cancelled: "Dibatalkan",
};

export default function Home() {
  const [view, setView] = useState<"landing" | "admin">("landing");
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [config, setConfig] = useState<SiteConfig>({
    site_name: "LES KOMPUTER",
    site_tagline: "Mahasiswa, SMA/SMK Sederajat, Umum",
    site_phone: "0812-3456-7890",
    site_email: "info@leskomputer.id",
    site_address: "Jl. Teknologi No. 123, Jakarta Selatan",
    site_whatsapp: "6281234567890",
    site_hero_image: "/hero-image.png",
    site_about_image: "/about-image.png",
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });
  const [loginLoading, setLoginLoading] = useState(false);
  const [adminTab, setAdminTab] = useState("dashboard");
  const { toast } = useToast();

  // Dialog states
  const [courseDialog, setCourseDialog] = useState<{ open: boolean; mode: "create" | "edit"; data?: Course }>({
    open: false,
    mode: "create",
  });
  const [testimonialDialog, setTestimonialDialog] = useState<{ open: boolean; mode: "create" | "edit"; data?: Testimonial }>({
    open: false,
    mode: "create",
  });
  const [enrollDialog, setEnrollDialog] = useState<{ open: boolean; courseId?: string }>({ open: false });
  const [loading, setLoading] = useState(false);

  // Form states
  const [courseForm, setCourseForm] = useState({
    title: "", description: "", icon: "Monitor", duration: "8 Pertemuan",
    price: 0, level: "Pemula", features: "", image: "", isActive: true, order: 0,
  });
  const [testimonialForm, setTestimonialForm] = useState({
    name: "", role: "", content: "", rating: 5, isActive: true, order: 0,
  });
  const [enrollForm, setEnrollForm] = useState({
    name: "", email: "", phone: "", courseId: "", message: "",
  });

  // Image upload
  const heroImageRef = useRef<HTMLInputElement>(null);
  const aboutImageRef = useRef<HTMLInputElement>(null);
  const [uploadingImage, setUploadingImage] = useState<string | null>(null);

  const handleImageUpload = async (file: File, configKey: string) => {
    if (file.size > 20 * 1024 * 1024) {
      toast({ title: "File terlalu besar", description: "Ukuran maksimal 20MB", variant: "destructive" });
      return;
    }
    setUploadingImage(configKey);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("configKey", configKey);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (data.success) {
        setConfig((prev) => ({ ...prev, [configKey]: data.path + "?t=" + Date.now() }));
        toast({ title: "Foto berhasil diunggah!" });
      } else {
        toast({ title: "Gagal mengunggah", description: data.message, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Gagal mengunggah file", variant: "destructive" });
    }
    setUploadingImage(null);
  };

  // Fetch data
  const fetchCourses = async (isAdmin = false) => {
    const res = await fetch(`/api/courses${isAdmin ? "?admin=true" : ""}`);
    const data = await res.json();
    setCourses(data.courses || []);
  };

  const fetchTestimonials = async () => {
    const res = await fetch("/api/testimonials");
    const data = await res.json();
    setTestimonials(data.testimonials || []);
  };

  const fetchEnrollments = async () => {
    const res = await fetch("/api/enrollments");
    const data = await res.json();
    setEnrollments(data.enrollments || []);
  };

  const fetchConfig = async () => {
    const res = await fetch("/api/config");
    const data = await res.json();
    if (data.config) setConfig((prev) => ({ ...prev, ...data.config }));
  };

  const checkAuth = async () => {
    const res = await fetch("/api/auth/check");
    const data = await res.json();
    if (data.authenticated) {
      setAdmin(data.admin);
      setView("admin");
    }
  };

  useEffect(() => {
    const loadData = async () => {
      const [coursesRes, testimonialsRes, configRes, authRes] = await Promise.all([
        fetch("/api/courses"),
        fetch("/api/testimonials"),
        fetch("/api/config"),
        fetch("/api/auth/check"),
      ]);
      const coursesData = await coursesRes.json();
      const testimonialsData = await testimonialsRes.json();
      const configData = await configRes.json();
      const authData = await authRes.json();

      setCourses(coursesData.courses || []);
      setTestimonials(testimonialsData.testimonials || []);
      if (configData.config) setConfig((prev) => ({ ...prev, ...configData.config }));
      if (authData.authenticated) {
        setAdmin(authData.admin);
        setView("admin");
      }
    };
    loadData();
  }, []);

  // Login
  const handleLogin = async () => {
    setLoginLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginForm),
      });
      const data = await res.json();
      if (data.success) {
        setAdmin(data.admin);
        setView("admin");
        setLoginOpen(false);
        setLoginForm({ username: "", password: "" });
        fetchCourses(true);
        fetchEnrollments();
        toast({ title: "Login berhasil!", description: `Selamat datang, ${data.admin.name}` });
      } else {
        toast({ title: "Login gagal", description: data.message, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Terjadi kesalahan saat login", variant: "destructive" });
    }
    setLoginLoading(false);
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setAdmin(null);
    setView("landing");
    fetchCourses();
    toast({ title: "Logout berhasil", description: "Anda telah keluar dari panel admin" });
  };

  // Course CRUD
  const openCourseDialog = (mode: "create" | "edit", course?: Course) => {
    if (mode === "edit" && course) {
      setCourseForm({
        title: course.title, description: course.description, icon: course.icon,
        duration: course.duration, price: course.price, level: course.level,
        features: course.features, image: course.image || "", isActive: course.isActive, order: course.order,
      });
    } else {
      setCourseForm({
        title: "", description: "", icon: "Monitor", duration: "8 Pertemuan",
        price: 0, level: "Pemula", features: "", image: "", isActive: true, order: 0,
      });
    }
    setCourseDialog({ open: true, mode, data: course });
  };

  const saveCourse = async () => {
    setLoading(true);
    try {
      const url = courseDialog.mode === "create" ? "/api/courses" : `/api/courses/${courseDialog.data?.id}`;
      const method = courseDialog.mode === "create" ? "POST" : "PUT";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(courseForm),
      });
      const data = await res.json();
      if (data.success) {
        toast({ title: courseDialog.mode === "create" ? "Kursus ditambahkan" : "Kursus diperbarui" });
        setCourseDialog({ open: false, mode: "create" });
        fetchCourses(true);
      } else {
        toast({ title: "Gagal", description: data.message, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", variant: "destructive" });
    }
    setLoading(false);
  };

  const deleteCourse = async (id: string) => {
    if (!confirm("Yakin ingin menghapus kursus ini?")) return;
    const res = await fetch(`/api/courses/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) {
      toast({ title: "Kursus dihapus" });
      fetchCourses(true);
    }
  };

  // Testimonial CRUD
  const openTestimonialDialog = (mode: "create" | "edit", testimonial?: Testimonial) => {
    if (mode === "edit" && testimonial) {
      setTestimonialForm({
        name: testimonial.name, role: testimonial.role, content: testimonial.content,
        rating: testimonial.rating, isActive: testimonial.isActive, order: testimonial.order,
      });
    } else {
      setTestimonialForm({ name: "", role: "", content: "", rating: 5, isActive: true, order: 0 });
    }
    setTestimonialDialog({ open: true, mode, data: testimonial });
  };

  const saveTestimonial = async () => {
    setLoading(true);
    try {
      const url = testimonialDialog.mode === "create" ? "/api/testimonials" : `/api/testimonials/${testimonialDialog.data?.id}`;
      const method = testimonialDialog.mode === "create" ? "POST" : "PUT";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(testimonialForm),
      });
      const data = await res.json();
      if (data.success) {
        toast({ title: testimonialDialog.mode === "create" ? "Testimoni ditambahkan" : "Testimoni diperbarui" });
        setTestimonialDialog({ open: false, mode: "create" });
        fetchTestimonials();
      } else {
        toast({ title: "Gagal", description: data.message, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", variant: "destructive" });
    }
    setLoading(false);
  };

  const deleteTestimonial = async (id: string) => {
    if (!confirm("Yakin ingin menghapus testimoni ini?")) return;
    const res = await fetch(`/api/testimonials/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) {
      toast({ title: "Testimoni dihapus" });
      fetchTestimonials();
    }
  };

  // Enrollment
  const handleEnroll = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/enrollments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(enrollForm),
      });
      const data = await res.json();
      if (data.success) {
        toast({ title: "Pendaftaran berhasil!", description: "Kami akan menghubungi Anda segera." });
        setEnrollDialog({ open: false });
        setEnrollForm({ name: "", email: "", phone: "", courseId: "", message: "" });
      } else {
        toast({ title: "Gagal mendaftar", description: data.message, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", variant: "destructive" });
    }
    setLoading(false);
  };

  const updateEnrollmentStatus = async (id: string, status: string) => {
    const res = await fetch(`/api/enrollments/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (data.success) {
      toast({ title: "Status diperbarui" });
      fetchEnrollments();
    }
  };

  const deleteEnrollment = async (id: string) => {
    if (!confirm("Yakin ingin menghapus pendaftaran ini?")) return;
    const res = await fetch(`/api/enrollments/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) {
      toast({ title: "Pendaftaran dihapus" });
      fetchEnrollments();
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(price);
  };

  // ============ LANDING PAGE ============
  if (view === "landing") {
    return (
      <div className="min-h-screen flex flex-col bg-white">
        {/* Navbar */}
        <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-lg flex items-center justify-center">
                  <Monitor className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent">
                  {config.site_name}
                </span>
              </div>
              <div className="hidden md:flex items-center gap-6">
                <a href="#kursus" className="text-sm font-medium text-gray-600 hover:text-teal-600 transition-colors">Kursus</a>
                <a href="#tentang" className="text-sm font-medium text-gray-600 hover:text-teal-600 transition-colors">Tentang</a>
                <a href="#testimoni" className="text-sm font-medium text-gray-600 hover:text-teal-600 transition-colors">Testimoni</a>
                <a href="#kontak" className="text-sm font-medium text-gray-600 hover:text-teal-600 transition-colors">Kontak</a>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLoginOpen(true)}
                  className="border-teal-200 text-teal-600 hover:bg-teal-50"
                >
                  Admin
                </Button>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
          {/* Mobile menu */}
          <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="md:hidden overflow-hidden border-t border-gray-100 bg-white"
              >
                <div className="px-4 py-3 space-y-2">
                  <a href="#kursus" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-sm font-medium text-gray-600 hover:text-teal-600">Kursus</a>
                  <a href="#tentang" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-sm font-medium text-gray-600 hover:text-teal-600">Tentang</a>
                  <a href="#testimoni" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-sm font-medium text-gray-600 hover:text-teal-600">Testimoni</a>
                  <a href="#kontak" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-sm font-medium text-gray-600 hover:text-teal-600">Kontak</a>
                  <Button variant="outline" size="sm" onClick={() => { setLoginOpen(true); setMobileMenuOpen(false); }} className="w-full border-teal-200 text-teal-600">
                    Admin Login
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </nav>

        <main className="flex-1">
          {/* Hero Section */}
          <section className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-50 via-emerald-50 to-cyan-50" />
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-20 left-10 w-72 h-72 bg-teal-400 rounded-full blur-3xl" />
              <div className="absolute bottom-10 right-10 w-96 h-96 bg-emerald-400 rounded-full blur-3xl" />
            </div>
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <Badge className="mb-4 bg-teal-100 text-teal-700 hover:bg-teal-100">
                    <Zap className="w-3 h-3 mr-1" /> Pendaftaran Dibuka!
                  </Badge>
                  <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-gray-900">
                    Les Komputer untuk{" "}
                    <span className="bg-gradient-to-r from-teal-600 to-emerald-500 bg-clip-text text-transparent">
                      Mahasiswa, SMA/SMK &amp; Umum
                    </span>
                  </h1>
                  <p className="mt-6 text-lg text-gray-600 max-w-lg">
                    Belajar komputer dari dasar hingga mahir dengan pengajar berpengalaman dan kurikulum yang terstruktur. Untuk semua kaluan — mahasiswa, pelajar SMA/SMK sederajat, dan masyarakat umum.
                  </p>
                  <div className="mt-8 flex flex-col sm:flex-row gap-3">
                    <Button
                      size="lg"
                      className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white shadow-lg shadow-teal-200"
                      onClick={() => document.getElementById("kursus")?.scrollIntoView({ behavior: "smooth" })}
                    >
                      Lihat Kursus <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-teal-200 text-teal-700 hover:bg-teal-50"
                      onClick={() => window.open(`https://wa.me/${config.site_whatsapp}`, "_blank")}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" /> Hubungi Kami
                    </Button>
                  </div>
                  <div className="mt-8 flex gap-8">
                    <div>
                      <p className="text-2xl font-bold text-gray-900">500+</p>
                      <p className="text-sm text-gray-500">Alumni</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">6+</p>
                      <p className="text-sm text-gray-500">Program Kursus</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">98%</p>
                      <p className="text-sm text-gray-500">Kepuasan</p>
                    </div>
                  </div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="relative"
                >
                  <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-teal-200/50">
                    <img
                      src={config.site_hero_image || "/hero-image.png"}
                      alt="Kelas LES KOMPUTER"
                      className="w-full h-auto object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                  </div>
                  <div className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg p-3 flex items-center gap-2">
                    <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-900">Tersertifikasi</p>
                      <p className="text-xs text-gray-500">Sertifikat resmi</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </section>

          {/* Courses Section */}
          <section id="kursus" className="py-16 sm:py-24 bg-gray-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-12"
              >
                <Badge className="mb-3 bg-teal-100 text-teal-700">Program Kursus</Badge>
                <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Pilih Kursus yang Sesuai</h2>
                <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
                  Kami menyediakan berbagai program kursus komputer dari tingkat pemula hingga lanjutan
                </p>
              </motion.div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {courses.filter((c) => c.isActive).map((course, i) => {
                  const IconComp = iconMap[course.icon] || Monitor;
                  return (
                    <motion.div
                      key={course.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <Card className="h-full hover:shadow-lg transition-shadow border-gray-200 group">
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                              <IconComp className="w-6 h-6 text-white" />
                            </div>
                            <Badge className={levelColors[course.level] || "bg-gray-100 text-gray-700"}>
                              {course.level}
                            </Badge>
                          </div>
                          <CardTitle className="mt-3 text-lg">{course.title}</CardTitle>
                          <CardDescription>{course.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {course.features.split("|").map((f, idx) => (
                              <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                                <CheckCircle className="w-4 h-4 text-teal-500 flex-shrink-0" />
                                {f.trim()}
                              </div>
                            ))}
                          </div>
                          <div className="mt-4 flex items-center gap-2 text-sm text-gray-500">
                            <Clock className="w-4 h-4" /> {course.duration}
                          </div>
                        </CardContent>
                        <CardFooter className="flex items-center justify-between">
                          <div>
                            <p className="text-2xl font-bold text-teal-600">{formatPrice(course.price)}</p>
                            <p className="text-xs text-gray-400">per program</p>
                          </div>
                          <Button
                            className="bg-teal-600 hover:bg-teal-700 text-white"
                            onClick={() => {
                              setEnrollForm((prev) => ({ ...prev, courseId: course.id }));
                              setEnrollDialog({ open: true, courseId: course.id });
                            }}
                          >
                            Daftar <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* About Section */}
          <section id="tentang" className="py-16 sm:py-24 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                >
                  <div className="relative">
                    <div className="rounded-2xl overflow-hidden shadow-xl">
                      <img src={config.site_about_image || "/about-image.png"} alt="Tentang LES KOMPUTER" className="w-full h-auto" />
                    </div>
                    <div className="absolute -top-4 -right-4 w-24 h-24 bg-teal-100 rounded-2xl -z-10" />
                    <div className="absolute -bottom-4 -left-4 w-24 h-24 bg-emerald-100 rounded-2xl -z-10" />
                  </div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                >
                  <Badge className="mb-3 bg-teal-100 text-teal-700">Mengapa Kami?</Badge>
                  <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Kenapa Memilih {config.site_name}?</h2>
                  <p className="mt-4 text-gray-600">
                    Kami berdedikasi untuk memberikan les komputer berkualitas untuk mahasiswa, pelajar SMA/SMK sederajat, dan masyarakat umum dengan pendekatan yang mudah dipahami dan langsung praktik.
                  </p>
                  <div className="mt-8 space-y-4">
                    {[
                      { icon: GraduationCap, title: "Pengajar Berpengalaman", desc: "Diajar oleh instruktur bersertifikasi dengan pengalaman bertahun-tahun" },
                      { icon: Award, title: "Sertifikat Resmi", desc: "Dapatkan sertifikat kompetensi yang diakui setelah menyelesaikan kursus" },
                      { icon: Zap, title: "Praktik Langsung", desc: "Belajar sambil praktik di laboratorium komputer yang lengkap" },
                      { icon: Heart, title: "Bimbingan Personal", desc: "Kelas kecil dengan perhatian khusus untuk setiap peserta" },
                    ].map((item, i) => (
                      <div key={i} className="flex gap-4 items-start">
                        <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0">
                          <item.icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{item.title}</h3>
                          <p className="text-sm text-gray-600">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </div>
            </div>
          </section>

          {/* Testimonials Section */}
          <section id="testimoni" className="py-16 sm:py-24 bg-gradient-to-br from-teal-50 via-emerald-50 to-cyan-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-12"
              >
                <Badge className="mb-3 bg-teal-100 text-teal-700">Testimoni</Badge>
                <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Apa Kata Mereka?</h2>
                <p className="mt-3 text-gray-600">Dengarkan pengalaman alumni kami</p>
              </motion.div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-6">
                {testimonials.filter((t) => t.isActive).map((t, i) => (
                  <motion.div
                    key={t.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <Card className="h-full border-0 shadow-md bg-white/80 backdrop-blur-sm">
                      <CardContent className="pt-6">
                        <div className="flex gap-1 mb-3">
                          {Array.from({ length: 5 }).map((_, idx) => (
                            <Star
                              key={idx}
                              className={`w-4 h-4 ${idx < t.rating ? "text-amber-400 fill-amber-400" : "text-gray-200"}`}
                            />
                          ))}
                        </div>
                        <p className="text-gray-700 italic">&quot;{t.content}&quot;</p>
                        <div className="mt-4 flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            {t.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{t.name}</p>
                            <p className="text-sm text-gray-500">{t.role}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Contact Section */}
          <section id="kontak" className="py-16 sm:py-24 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-12"
              >
                <Badge className="mb-3 bg-teal-100 text-teal-700">Kontak</Badge>
                <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Hubungi Kami</h2>
                <p className="mt-3 text-gray-600">Siap membantu Anda memulai perjalanan belajar</p>
              </motion.div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { icon: Phone, label: "Telepon", value: config.site_phone, href: `tel:${config.site_phone}` },
                  { icon: MessageCircle, label: "WhatsApp", value: config.site_phone, href: `https://wa.me/${config.site_whatsapp}` },
                  { icon: Mail, label: "Email", value: config.site_email, href: `mailto:${config.site_email}` },
                  { icon: MapPin, label: "Alamat", value: config.site_address, href: "#" },
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <a href={item.href} target={item.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer">
                      <Card className="h-full text-center hover:shadow-lg transition-shadow border-gray-200 cursor-pointer group">
                        <CardContent className="pt-6">
                          <div className="w-14 h-14 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-teal-200 transition-colors">
                            <item.icon className="w-6 h-6 text-teal-600" />
                          </div>
                          <h3 className="font-semibold text-gray-900">{item.label}</h3>
                          <p className="text-sm text-gray-600 mt-1">{item.value}</p>
                        </CardContent>
                      </Card>
                    </a>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-16 sm:py-20 bg-gradient-to-r from-teal-600 to-emerald-600">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <h2 className="text-3xl sm:text-4xl font-bold text-white">Siap Memulai Belajar?</h2>
              <p className="mt-4 text-teal-100 text-lg">
                Daftarkan diri Anda sekarang dan mulai perjalanan menguasai teknologi
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
                <Button
                  size="lg"
                  className="bg-white text-teal-700 hover:bg-gray-100 shadow-lg"
                  onClick={() => document.getElementById("kursus")?.scrollIntoView({ behavior: "smooth" })}
                >
                  Daftar Sekarang <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10"
                  onClick={() => window.open(`https://wa.me/${config.site_whatsapp}`, "_blank")}
                >
                  <MessageCircle className="w-4 h-4 mr-2" /> Chat WhatsApp
                </Button>
              </div>
            </div>
          </section>
        </main>

        {/* Footer */}
        <footer className="bg-gray-900 text-gray-400 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-lg flex items-center justify-center">
                    <Monitor className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-lg font-bold text-white">{config.site_name}</span>
                </div>
                <p className="text-sm">{config.site_tagline}</p>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-3">Kursus</h3>
                <ul className="space-y-2 text-sm">
                  {courses.filter((c) => c.isActive).slice(0, 4).map((c) => (
                    <li key={c.id}>
                      <a href="#kursus" className="hover:text-teal-400 transition-colors">{c.title}</a>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-3">Kontak</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2"><Phone className="w-4 h-4" /> {config.site_phone}</li>
                  <li className="flex items-center gap-2"><Mail className="w-4 h-4" /> {config.site_email}</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-3">Alamat</h3>
                <p className="text-sm flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" /> {config.site_address}
                </p>
              </div>
            </div>
            <Separator className="my-8 bg-gray-800" />
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-sm">
              <p>&copy; {new Date().getFullYear()} {config.site_name}. Hak cipta dilindungi.</p>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLoginOpen(true)}
                className="text-gray-500 hover:text-gray-300"
              >
                <Settings className="w-4 h-4 mr-1" /> Admin
              </Button>
            </div>
          </div>
        </footer>

        {/* Login Dialog */}
        <Dialog open={loginOpen} onOpenChange={setLoginOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-lg flex items-center justify-center">
                  <LayoutDashboard className="w-4 h-4 text-white" />
                </div>
                Login Admin
              </DialogTitle>
              <DialogDescription>Masuk ke panel pengelolaan {config.site_name}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Username</Label>
                <Input
                  placeholder="Masukkan username"
                  value={loginForm.username}
                  onChange={(e) => setLoginForm((prev) => ({ ...prev, username: e.target.value }))}
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <Input
                  type="password"
                  placeholder="Masukkan password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm((prev) => ({ ...prev, password: e.target.value }))}
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={handleLogin}
                disabled={loginLoading}
                className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white w-full"
              >
                {loginLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Masuk
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Enrollment Dialog */}
        <Dialog open={enrollDialog.open} onOpenChange={(open) => setEnrollDialog({ open })}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Daftar Kursus</DialogTitle>
              <DialogDescription>Isi formulir untuk mendaftar kursus</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Nama Lengkap</Label>
                <Input
                  placeholder="Masukkan nama lengkap"
                  value={enrollForm.name}
                  onChange={(e) => setEnrollForm((prev) => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  placeholder="Masukkan email"
                  value={enrollForm.email}
                  onChange={(e) => setEnrollForm((prev) => ({ ...prev, email: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>No. Telepon</Label>
                <Input
                  placeholder="Masukkan nomor telepon"
                  value={enrollForm.phone}
                  onChange={(e) => setEnrollForm((prev) => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Pilih Kursus</Label>
                <Select
                  value={enrollForm.courseId}
                  onValueChange={(value) => setEnrollForm((prev) => ({ ...prev, courseId: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih kursus" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.filter((c) => c.isActive).map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.title} - {formatPrice(c.price)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Pesan (opsional)</Label>
                <Textarea
                  placeholder="Tulis pesan atau pertanyaan"
                  value={enrollForm.message}
                  onChange={(e) => setEnrollForm((prev) => ({ ...prev, message: e.target.value }))}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={handleEnroll}
                disabled={loading || !enrollForm.name || !enrollForm.email || !enrollForm.phone || !enrollForm.courseId}
                className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white w-full"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Daftar Sekarang
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Toaster />
      </div>
    );
  }

  // ============ ADMIN DASHBOARD ============
  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <aside className="hidden lg:flex lg:flex-col w-64 bg-white border-r border-gray-200">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-lg flex items-center justify-center">
              <Monitor className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-bold text-gray-900">{config.site_name}</p>
              <p className="text-xs text-gray-500">Panel Admin</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {[
            { key: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
            { key: "courses", icon: BookOpen, label: "Kelola Kursus" },
            { key: "testimonials", icon: MessageSquare, label: "Kelola Testimoni" },
            { key: "enrollments", icon: Users, label: "Pendaftaran" },
            { key: "settings", icon: Settings, label: "Pengaturan" },
          ].map((item) => (
            <button
              key={item.key}
              onClick={() => setAdminTab(item.key)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                adminTab === item.key
                  ? "bg-teal-50 text-teal-700"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center text-teal-700 font-bold text-sm">
              {admin?.name?.charAt(0) || "A"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{admin?.name}</p>
              <p className="text-xs text-gray-500 truncate">{admin?.username}</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={handleLogout} className="w-full border-gray-200">
            <LogOut className="w-4 h-4 mr-2" /> Keluar
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header */}
        <header className="lg:hidden sticky top-0 z-50 bg-white border-b border-gray-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-lg flex items-center justify-center">
                <Monitor className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-gray-900">Admin</span>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
          {/* Mobile tabs */}
          <div className="flex gap-1 mt-3 overflow-x-auto pb-1">
            {[
              { key: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
              { key: "courses", icon: BookOpen, label: "Kursus" },
              { key: "testimonials", icon: MessageSquare, label: "Testimoni" },
              { key: "enrollments", icon: Users, label: "Pendaftaran" },
              { key: "settings", icon: Settings, label: "Setting" },
            ].map((item) => (
              <button
                key={item.key}
                onClick={() => setAdminTab(item.key)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                  adminTab === item.key
                    ? "bg-teal-100 text-teal-700"
                    : "text-gray-500 hover:bg-gray-100"
                }`}
              >
                <item.icon className="w-3 h-3" />
                {item.label}
              </button>
            ))}
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            {/* Dashboard */}
            {adminTab === "dashboard" && (
              <motion.div key="dashboard" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <h1 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h1>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  {[
                    { label: "Total Kursus", value: courses.length, icon: BookOpen, color: "from-teal-500 to-emerald-600" },
                    { label: "Kursus Aktif", value: courses.filter((c) => c.isActive).length, icon: Eye, color: "from-cyan-500 to-teal-600" },
                    { label: "Testimoni", value: testimonials.length, icon: MessageSquare, color: "from-amber-500 to-orange-600" },
                    { label: "Pendaftaran", value: enrollments.length, icon: Users, color: "from-rose-500 to-pink-600" },
                  ].map((stat, i) => (
                    <Card key={i} className="border-0 shadow-sm">
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-500">{stat.label}</p>
                            <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                          </div>
                          <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center`}>
                            <stat.icon className="w-6 h-6 text-white" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                {/* Recent enrollments */}
                <Card className="border-0 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-lg">Pendaftaran Terbaru</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {enrollments.length === 0 ? (
                      <p className="text-gray-500 text-sm text-center py-4">Belum ada pendaftaran</p>
                    ) : (
                      <div className="space-y-3 max-h-96 overflow-y-auto">
                        {enrollments.slice(0, 5).map((e) => (
                          <div key={e.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{e.name}</p>
                              <p className="text-sm text-gray-500">{e.course?.title || "Kursus"}</p>
                            </div>
                            <Badge className={statusColors[e.status] || "bg-gray-100 text-gray-700"}>
                              {statusLabels[e.status] || e.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Courses Management */}
            {adminTab === "courses" && (
              <motion.div key="courses" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <div className="flex items-center justify-between mb-6">
                  <h1 className="text-2xl font-bold text-gray-900">Kelola Kursus</h1>
                  <Button
                    onClick={() => openCourseDialog("create")}
                    className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" /> Tambah Kursus
                  </Button>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {courses.map((course) => {
                    const IconComp = iconMap[course.icon] || Monitor;
                    return (
                      <Card key={course.id} className={`border-0 shadow-sm ${!course.isActive ? "opacity-60" : ""}`}>
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-lg flex items-center justify-center">
                                <IconComp className="w-5 h-5 text-white" />
                              </div>
                              <div>
                                <CardTitle className="text-base">{course.title}</CardTitle>
                                <div className="flex gap-1 mt-1">
                                  <Badge variant="outline" className={levelColors[course.level]}>{course.level}</Badge>
                                  {!course.isActive && <Badge variant="outline" className="bg-gray-100 text-gray-500">Nonaktif</Badge>}
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <p className="text-sm text-gray-600 line-clamp-2 mb-2">{course.description}</p>
                          <p className="text-lg font-bold text-teal-600">{formatPrice(course.price)}</p>
                          <p className="text-xs text-gray-400">{course.duration}</p>
                        </CardContent>
                        <CardFooter className="pt-0 gap-2">
                          <Button variant="outline" size="sm" onClick={() => openCourseDialog("edit", course)} className="flex-1">
                            <Pencil className="w-3 h-3 mr-1" /> Edit
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => deleteCourse(course.id)} className="text-rose-600 hover:bg-rose-50 border-rose-200">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </CardFooter>
                      </Card>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* Testimonials Management */}
            {adminTab === "testimonials" && (
              <motion.div key="testimonials" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <div className="flex items-center justify-between mb-6">
                  <h1 className="text-2xl font-bold text-gray-900">Kelola Testimoni</h1>
                  <Button
                    onClick={() => openTestimonialDialog("create")}
                    className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" /> Tambah Testimoni
                  </Button>
                </div>
                <div className="space-y-3">
                  {testimonials.map((t) => (
                    <Card key={t.id} className={`border-0 shadow-sm ${!t.isActive ? "opacity-60" : ""}`}>
                      <CardContent className="pt-6">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-full flex items-center justify-center text-white font-bold text-xs">
                                {t.name.charAt(0)}
                              </div>
                              <div>
                                <p className="font-semibold text-gray-900">{t.name}</p>
                                <p className="text-xs text-gray-500">{t.role}</p>
                              </div>
                              <div className="flex gap-0.5 ml-2">
                                {Array.from({ length: 5 }).map((_, idx) => (
                                  <Star key={idx} className={`w-3 h-3 ${idx < t.rating ? "text-amber-400 fill-amber-400" : "text-gray-200"}`} />
                                ))}
                              </div>
                              {!t.isActive && <Badge variant="outline" className="bg-gray-100 text-gray-500 text-xs ml-2">Nonaktif</Badge>}
                            </div>
                            <p className="text-sm text-gray-600 italic">&quot;{t.content}&quot;</p>
                          </div>
                          <div className="flex gap-1 flex-shrink-0">
                            <Button variant="outline" size="sm" onClick={() => openTestimonialDialog("edit", t)}>
                              <Pencil className="w-3 h-3" />
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => deleteTestimonial(t.id)} className="text-rose-600 hover:bg-rose-50 border-rose-200">
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {testimonials.length === 0 && (
                    <Card className="border-0 shadow-sm">
                      <CardContent className="pt-6 text-center">
                        <p className="text-gray-500">Belum ada testimoni</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </motion.div>
            )}

            {/* Enrollments Management */}
            {adminTab === "enrollments" && (
              <motion.div key="enrollments" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <div className="flex items-center justify-between mb-6">
                  <h1 className="text-2xl font-bold text-gray-900">Pendaftaran</h1>
                  <Badge className="bg-teal-100 text-teal-700">{enrollments.length} pendaftar</Badge>
                </div>
                <div className="space-y-3">
                  {enrollments.map((e) => (
                    <Card key={e.id} className="border-0 shadow-sm">
                      <CardContent className="pt-6">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-semibold text-gray-900">{e.name}</p>
                              <Badge className={statusColors[e.status] || "bg-gray-100 text-gray-700"}>
                                {statusLabels[e.status] || e.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600">{e.course?.title || "Kursus"}</p>
                            <div className="flex flex-wrap gap-3 mt-2 text-xs text-gray-500">
                              <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {e.email}</span>
                              <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {e.phone}</span>
                              <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(e.createdAt).toLocaleDateString("id-ID")}</span>
                            </div>
                            {e.message && <p className="text-sm text-gray-500 mt-2 italic">&quot;{e.message}&quot;</p>}
                          </div>
                          <div className="flex gap-1 flex-shrink-0 flex-wrap">
                            {e.status !== "confirmed" && (
                              <Button variant="outline" size="sm" onClick={() => updateEnrollmentStatus(e.id, "confirmed")} className="text-emerald-600 border-emerald-200 hover:bg-emerald-50">
                                <CheckCircle className="w-3 h-3 mr-1" /> Konfirmasi
                              </Button>
                            )}
                            {e.status !== "completed" && (
                              <Button variant="outline" size="sm" onClick={() => updateEnrollmentStatus(e.id, "completed")} className="text-teal-600 border-teal-200 hover:bg-teal-50">
                                Selesai
                              </Button>
                            )}
                            {e.status !== "cancelled" && (
                              <Button variant="outline" size="sm" onClick={() => updateEnrollmentStatus(e.id, "cancelled")} className="text-amber-600 border-amber-200 hover:bg-amber-50">
                                <XCircle className="w-3 h-3 mr-1" /> Batal
                              </Button>
                            )}
                            <Button variant="outline" size="sm" onClick={() => deleteEnrollment(e.id)} className="text-rose-600 hover:bg-rose-50 border-rose-200">
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {enrollments.length === 0 && (
                    <Card className="border-0 shadow-sm">
                      <CardContent className="pt-6 text-center">
                        <p className="text-gray-500">Belum ada pendaftaran</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </motion.div>
            )}

            {/* Settings */}
            {adminTab === "settings" && (
              <motion.div key="settings" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                <h1 className="text-2xl font-bold text-gray-900 mb-6">Pengaturan Website</h1>

                {/* Image Management */}
                <Card className="border-0 shadow-sm mb-6">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ImageIcon className="w-5 h-5 text-teal-600" />
                      Kelola Foto Halaman Depan
                    </CardTitle>
                    <CardDescription>Ubah foto yang tampil di halaman depan website. Maksimal 20MB per file.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Hero Image */}
                    <div className="space-y-3">
                      <Label className="text-sm font-medium">Foto Hero (Bagian Atas)</Label>
                      <div className="relative rounded-xl overflow-hidden border-2 border-dashed border-gray-200 bg-gray-50">
                        <img
                          src={config.site_hero_image || "/hero-image.png"}
                          alt="Preview Hero"
                          className="w-full h-48 sm:h-64 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/0 hover:bg-black/30 transition-colors flex items-center justify-center group cursor-pointer"
                          onClick={() => heroImageRef.current?.click()}
                        >
                          <div className="bg-white/90 rounded-lg px-4 py-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2">
                            {uploadingImage === "site_hero_image" ? (
                              <><Loader2 className="w-4 h-4 animate-spin text-teal-600" /> <span className="text-sm font-medium">Mengunggah...</span></>
                            ) : (
                              <><Upload className="w-4 h-4 text-teal-600" /> <span className="text-sm font-medium">Ganti Foto</span></>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-gray-500">Format: JPG, PNG, GIF, WebP, SVG • Maks: 20MB</p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => heroImageRef.current?.click()}
                          disabled={uploadingImage === "site_hero_image"}
                          className="border-teal-200 text-teal-700 hover:bg-teal-50"
                        >
                          {uploadingImage === "site_hero_image" ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                          Unggah Foto Hero
                        </Button>
                      </div>
                      <input
                        ref={heroImageRef}
                        type="file"
                        accept="image/jpeg,image/png,image/gif,image/webp,image/svg+xml"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleImageUpload(file, "site_hero_image");
                          e.target.value = "";
                        }}
                      />
                    </div>

                    <Separator />

                    {/* About Image */}
                    <div className="space-y-3">
                      <Label className="text-sm font-medium">Foto Tentang Kami</Label>
                      <div className="relative rounded-xl overflow-hidden border-2 border-dashed border-gray-200 bg-gray-50">
                        <img
                          src={config.site_about_image || "/about-image.png"}
                          alt="Preview About"
                          className="w-full h-48 sm:h-64 object-cover"
                        />
                        <div className="absolute inset-0 bg-black/0 hover:bg-black/30 transition-colors flex items-center justify-center group cursor-pointer"
                          onClick={() => aboutImageRef.current?.click()}
                        >
                          <div className="bg-white/90 rounded-lg px-4 py-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2">
                            {uploadingImage === "site_about_image" ? (
                              <><Loader2 className="w-4 h-4 animate-spin text-teal-600" /> <span className="text-sm font-medium">Mengunggah...</span></>
                            ) : (
                              <><Upload className="w-4 h-4 text-teal-600" /> <span className="text-sm font-medium">Ganti Foto</span></>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-gray-500">Format: JPG, PNG, GIF, WebP, SVG • Maks: 20MB</p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => aboutImageRef.current?.click()}
                          disabled={uploadingImage === "site_about_image"}
                          className="border-teal-200 text-teal-700 hover:bg-teal-50"
                        >
                          {uploadingImage === "site_about_image" ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Upload className="w-4 h-4 mr-2" />}
                          Unggah Foto Tentang
                        </Button>
                      </div>
                      <input
                        ref={aboutImageRef}
                        type="file"
                        accept="image/jpeg,image/png,image/gif,image/webp,image/svg+xml"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleImageUpload(file, "site_about_image");
                          e.target.value = "";
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Text Config */}
                <Card className="border-0 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Settings className="w-5 h-5 text-teal-600" />
                      Informasi Website
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { key: "site_name", label: "Nama Website", icon: Monitor },
                      { key: "site_tagline", label: "Tagline", icon: Zap },
                      { key: "site_phone", label: "Telepon", icon: Phone },
                      { key: "site_email", label: "Email", icon: Mail },
                      { key: "site_address", label: "Alamat", icon: MapPin },
                      { key: "site_whatsapp", label: "WhatsApp (format: 6281234567890)", icon: MessageCircle },
                    ].map((item) => (
                      <div key={item.key} className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <item.icon className="w-5 h-5 text-teal-600" />
                        </div>
                        <div className="flex-1">
                          <Label className="text-sm">{item.label}</Label>
                          <Input
                            value={config[item.key] || ""}
                            onChange={(e) => setConfig((prev) => ({ ...prev, [item.key]: e.target.value }))}
                            className="mt-1"
                          />
                        </div>
                      </div>
                    ))}
                    <div className="flex justify-end pt-4">
                      <Button
                        onClick={async () => {
                          const textKeys = ["site_name", "site_tagline", "site_phone", "site_email", "site_address", "site_whatsapp"];
                          for (const key of textKeys) {
                            await fetch("/api/config", {
                              method: "PUT",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ key, value: config[key] || "" }),
                            });
                          }
                          toast({ title: "Pengaturan disimpan" });
                        }}
                        className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white"
                      >
                        Simpan Pengaturan
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Course Dialog */}
      <Dialog open={courseDialog.open} onOpenChange={(open) => setCourseDialog((prev) => ({ ...prev, open }))}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{courseDialog.mode === "create" ? "Tambah Kursus Baru" : "Edit Kursus"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2 col-span-2">
                <Label>Judul Kursus</Label>
                <Input
                  value={courseForm.title}
                  onChange={(e) => setCourseForm((prev) => ({ ...prev, title: e.target.value }))}
                  placeholder="Nama kursus"
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label>Deskripsi</Label>
                <Textarea
                  value={courseForm.description}
                  onChange={(e) => setCourseForm((prev) => ({ ...prev, description: e.target.value }))}
                  placeholder="Deskripsi singkat kursus"
                />
              </div>
              <div className="space-y-2">
                <Label>Ikon</Label>
                <Select value={courseForm.icon} onValueChange={(value) => setCourseForm((prev) => ({ ...prev, icon: value }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.keys(iconMap).map((key) => (
                      <SelectItem key={key} value={key}>{key}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Level</Label>
                <Select value={courseForm.level} onValueChange={(value) => setCourseForm((prev) => ({ ...prev, level: value }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pemula">Pemula</SelectItem>
                    <SelectItem value="Menengah">Menengah</SelectItem>
                    <SelectItem value="Lanjutan">Lanjutan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Durasi</Label>
                <Input
                  value={courseForm.duration}
                  onChange={(e) => setCourseForm((prev) => ({ ...prev, duration: e.target.value }))}
                  placeholder="cth: 8 Pertemuan"
                />
              </div>
              <div className="space-y-2">
                <Label>Harga (Rp)</Label>
                <Input
                  type="number"
                  value={courseForm.price}
                  onChange={(e) => setCourseForm((prev) => ({ ...prev, price: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label>Fitur (pisahkan dengan |)</Label>
                <Input
                  value={courseForm.features}
                  onChange={(e) => setCourseForm((prev) => ({ ...prev, features: e.target.value }))}
                  placeholder="cth: Word|Excel|PowerPoint"
                />
              </div>
              <div className="space-y-2">
                <Label>Urutan</Label>
                <Input
                  type="number"
                  value={courseForm.order}
                  onChange={(e) => setCourseForm((prev) => ({ ...prev, order: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="flex items-center gap-3 pt-6">
                <Switch
                  checked={courseForm.isActive}
                  onCheckedChange={(checked) => setCourseForm((prev) => ({ ...prev, isActive: checked }))}
                />
                <Label>Aktif</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCourseDialog({ open: false, mode: "create" })}>Batal</Button>
            <Button
              onClick={saveCourse}
              disabled={loading || !courseForm.title}
              className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {courseDialog.mode === "create" ? "Tambah" : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Testimonial Dialog */}
      <Dialog open={testimonialDialog.open} onOpenChange={(open) => setTestimonialDialog((prev) => ({ ...prev, open }))}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{testimonialDialog.mode === "create" ? "Tambah Testimoni" : "Edit Testimoni"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Nama</Label>
              <Input
                value={testimonialForm.name}
                onChange={(e) => setTestimonialForm((prev) => ({ ...prev, name: e.target.value }))}
                placeholder="Nama lengkap"
              />
            </div>
            <div className="space-y-2">
              <Label>Peran/Profesi</Label>
              <Input
                value={testimonialForm.role}
                onChange={(e) => setTestimonialForm((prev) => ({ ...prev, role: e.target.value }))}
                placeholder="cth: Mahasiswa, Karyawan"
              />
            </div>
            <div className="space-y-2">
              <Label>Testimoni</Label>
              <Textarea
                value={testimonialForm.content}
                onChange={(e) => setTestimonialForm((prev) => ({ ...prev, content: e.target.value }))}
                placeholder="Tulis testimoni"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Rating</Label>
                <Select value={String(testimonialForm.rating)} onValueChange={(value) => setTestimonialForm((prev) => ({ ...prev, rating: parseInt(value) }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5].map((r) => (
                      <SelectItem key={r} value={String(r)}>{r} Bintang</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Urutan</Label>
                <Input
                  type="number"
                  value={testimonialForm.order}
                  onChange={(e) => setTestimonialForm((prev) => ({ ...prev, order: parseInt(e.target.value) || 0 }))}
                />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={testimonialForm.isActive}
                onCheckedChange={(checked) => setTestimonialForm((prev) => ({ ...prev, isActive: checked }))}
              />
              <Label>Aktif</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTestimonialDialog({ open: false, mode: "create" })}>Batal</Button>
            <Button
              onClick={saveTestimonial}
              disabled={loading || !testimonialForm.name || !testimonialForm.content}
              className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {testimonialDialog.mode === "create" ? "Tambah" : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Toaster />
    </div>
  );
}
